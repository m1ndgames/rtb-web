import sc2
import os
# Ai-Arena example bot

class exampleAI(sc2.BotAI):
    def __init__(self):
        self.microActions = []
        self.pre_step_units = {}
        self.pre_step_reward = 0
        self.reward = 0
        self.known_enemies = 0
        self.start_unit_count = 0
        self.alive_unit_count = 0

    async def save_unit(self, unit):
        self.pre_step_units[unit.tag] = unit

    async def read_unit(self, unit):
        if unit.tag in self.pre_step_units:
            return self.pre_step_units[unit.tag]

    def _prepare_first_step(self):
        pass

    async def on_step(self, iteration):
        if iteration == 0:
            for unit in self.units:
                await self.save_unit(unit)
                if unit.is_mine:
                    self.start_unit_count = self.start_unit_count + 1

        # Clear microActions
        self.microActions = []

        # Clear pre_step_units on reset
        if not self.state.units:
            self.pre_step_units = {}
            return

        # Reward
        # Enemy units
        self.known_enemies = 0
        for enemy_unit in self.state.units:
            if not enemy_unit.is_mine:
                self.known_enemies = self.known_enemies + 1

                pre_step_enemy_unit = await self.read_unit(enemy_unit)
                if not pre_step_enemy_unit:
                    continue

                if enemy_unit.health < pre_step_enemy_unit.health:
                    self.reward = self.reward + 0.25

                elif enemy_unit.shield < pre_step_enemy_unit.shield:
                    self.reward = self.reward + 0.1

        # My units
        self.alive_unit_count = 0
        for my_unit in self.units.owned:

            self.alive_unit_count = self.alive_unit_count + 1

            pre_step_my_unit = await self.read_unit(my_unit)
            if not pre_step_my_unit:
                await self.save_unit(my_unit)
                continue

            if my_unit.health < pre_step_my_unit.health:
                self.reward = self.reward - 0.2

            elif my_unit.shield < pre_step_my_unit.shield:
                self.reward = self.reward - 0.1

        # Time
        if self.state.game_loop % 24 == 0:
            self.reward = self.reward - 0.025

        os.system('cls')
        print("Tick: " + str(iteration))
        print("Time: " + str(self.time))
        print("")
        print("Reward: " + str(self.reward))
        print("Units: " + str(self.alive_unit_count) + "/" + str(self.start_unit_count))
        print("Enemies: " + str(self.known_enemies))

        for unit in self.state.units:
            await self.save_unit(unit)

        for unit in self.units.ready:
            target = self.enemy_start_locations[0]
            self.microActions.append(unit.attack(target.position))

        await self.do_actions(self.microActions)

        self.pre_step_reward = self.reward
